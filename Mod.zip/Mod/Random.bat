@echo off
setlocal enabledelayedexpansion
chcp 65001 >nul
cd /d "%~dp0"
set "no1=briton"
set "no2=frankish"
set "no3=gothic"
set "no4=teutonic"
set "no5=japanese"
set "no6=chinese"
set "no7=byzantine"
set "no8=persian"
set "no9=saracen"
set "no10=turkish"
set "no11=viking"
set "no12=mongol"
set "no13=celtic"
set "no14=spanish"
set "no15=aztec"
set "no16=mayan"
set "no17=hun"
set "no18=korean"
set "no19=italian"
set "no20=indian"
set "no21=incan"
set "no22=magyar"
set "no23=slavic"
set "no24=portuguese"
set "no25=ethiopian"
set "no26=malian"
set "no27=berbers"
set "no28=khmer"
set "no29=malay"
set "no30=burmese"
set "no31=vietnamese"
set "count=0"
:loop
if !count! lss 8 (
    set "t=%TIME:~-2%"
    set /a "rand=(%RANDOM% + t) %% 31 + 1"
    set "chosen=0"
    for /l %%i in (1,1,!count!) do (
        if "!picked[%%i]!"=="!rand!" set "chosen=1"
    )
    if !chosen! equ 0 (
        set /a count+=1
        set "picked[!count!]=!rand!"
    )
    goto loop
)
> temp_Random.txt (
    echo =========================
    echo  Time: %DATE% %TIME%
    echo =========================
    for /l %%i in (1,1,8) do (
        for %%j in (!picked[%%i]!) do (
            echo %%i: !no%%j!
        )
    )
    if exist Random.txt (
        type Random.txt
    )
)
move /y temp_Random.txt Random.txt >nul
exit